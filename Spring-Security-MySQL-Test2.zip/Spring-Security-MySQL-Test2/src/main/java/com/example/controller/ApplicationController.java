package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



//@RequestMapping("/rest/auth/")
@RestController
public class ApplicationController {
	
	@GetMapping("/process")
	public String process() {
		
		System.out.println("==================inside process controller=============");
		
		return "processing.....";
	}

}
