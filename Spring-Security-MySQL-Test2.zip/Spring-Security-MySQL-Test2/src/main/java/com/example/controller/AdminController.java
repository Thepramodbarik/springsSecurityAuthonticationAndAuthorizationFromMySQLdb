package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.User2;
import com.example.service.AdminService;


//@RequestMapping("/secure/rest/")
@RestController
public class AdminController {

	@Autowired
	AdminService adminService;

	//@PreAuthorize("hasAnyRole('ROLE_ADMIN')")
	@PostMapping("/admin")
	public String addUserByAdmin(@RequestBody User2 user) {
		System.out.println("=====inside admin controller==============");
		String result = adminService.adminSave(user);
		System.out.println("===== result from controller " + result);
		return "Admin saved successfully...";
	}

}
