package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.model.User2;
import com.example.repository.UserRepository;

@Service
public class AdminService {
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public String adminSave(User2 user) {
		
		System.out.println("===========Inside service method============");
		
		String pwd = user.getPassword();
		String encryptpwd = bCryptPasswordEncoder.encode(pwd);
		user.setPassword(encryptpwd);

		userRepository.save(user);

		
		return "success";
	}

}
