package com.example.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import com.example.service.CustomUserDetailService;

@Configuration
@EnableWebSecurity(debug = true)
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

	@Bean
	public BCryptPasswordEncoder encodepwd() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public UserDetailsService userDetailsService(AuthenticationManagerBuilder auth) throws Exception {

		// auth.userDetailsService(userDetailsService(auth)).passwordEncoder(encodepwd());

		System.out.println("====================inside Userdetails Service==================");

		return new CustomUserDetailService();
	}

	/*
	 * @Autowired DataSource datasource;
	 * 
	 * 
	 * protected void configure(AuthenticationManagerBuilder auth) throws Exception
	 * {
	 * 
	 * System.out.
	 * println("================inside filter chain=configure=====AuthenticationManagerBuilder=========="
	 * ); auth.jdbcAuthentication().dataSource(datasource); }
	 */

	
	@Autowired 
	DataSource datasource;
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth)
	  throws Exception {
	    auth.jdbcAuthentication()
	      .dataSource(datasource)
	      .usersByUsernameQuery("select username,password,1 "
	    	        + "from user2 "
	    	        + "where username = ?")
	    	      .authoritiesByUsernameQuery("select u.username,r.role from user_role ur, role r ,user2 u "
	    	      		+ "where r.roleid=ur.roleid and ur.id=u.id and "
	    	      		+ "u.username = ?");
	}
	
	

	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		System.out.println("================inside filter chain================");

		http.csrf().disable()
	
		.authorizeHttpRequests()
		.requestMatchers("/admin").hasRole("ADMIN")
		.requestMatchers("/process") .permitAll()
				.anyRequest()
		.authenticated()
		.and()
		.formLogin().and().httpBasic();
		
		
		/*
		 * http.authorizeRequests().requestMatchers("/admin").authenticated().anyRequest
		 * ().hasAnyRole("ADMIN").and()
		 * .authorizeRequests().requestMatchers("/process").authenticated().anyRequest()
		 * .permitAll().and().formLogin();
		 */
		
		/*
		 * .authorizeHttpRequests() .requestMatchers("/admin").hasRole("ADMIN")
		 * .anyRequest() .authenticated() .and() .formLogin();
		 */

		/*
		 * http.authorizeHttpRequests().requestMatchers("/rest/**").authenticated().
		 * anyRequest().permitAll().and()
		 * .authorizeHttpRequests().requestMatchers("/secure/**").authenticated().
		 * anyRequest().permitAll();
		 */
		// http.csrf() .disable()

		return http.build();

	}

}
